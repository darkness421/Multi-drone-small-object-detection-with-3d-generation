# Slim Fig. 1 / Fig. 3 Revision Package

This is the clean handoff package for revising Main Fig. 1 and Main Fig. 3.
It excludes QA sheets, crop candidates, and extra scenario panels from the larger archive.

## Use These For Fig. 1

- `fig1_map_multiuav_preview.png`: real Cesium MarineCity multi-UAV overview.
- `fig1_uav01_rgb.png`, `fig1_uav02_rgb.png`, `fig1_uav03_rgb.png`: three UAV camera views.
- `fig1_uav01_isaac_bbox.png`, `fig1_uav02_isaac_bbox.png`, `fig1_uav03_isaac_bbox.png`: object-layout / bbox previews.

## Use These For Fig. 3

- `fig3_real_cesium_detector_preview_contact_sheet.png`: real-Cesium detector preview.
- `fig3_uav01_yolo_detection.png`, `fig3_uav02_yolo_detection.png`, `fig3_uav03_yolo_detection.png`: UAV-level detector examples.
- `fig3_crossview_evidence_graph_smoke.png`: cross-view EvidenceToken graph.
- `fig3_depth_pointcloud_smoke_topdown.png`: depth / point-cloud smoke preview.
- `fig3_evidence_tokens.jsonl`: detector EvidenceToken source.
- `fig3_detector_smoke_summary.json`: detector smoke-test summary.

## Pending Panels

- `fig3_final_neural3d_completion_render.png`: placeholder until final neural 3D completion output is ready.
- `fig3_final_nonmock_aerograph_decision_panel.png`: placeholder until final non-mock reasoner output is ready.

Keep pending panels visually marked as pending in the figure until final simulation/reasoner experiments are complete.
